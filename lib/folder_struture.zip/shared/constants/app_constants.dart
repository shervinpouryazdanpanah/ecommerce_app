class AppConstants {
  static const String endpoint = 'https://fakestoreapi.com';
}
